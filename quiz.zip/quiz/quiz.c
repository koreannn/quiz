#include <stdio.h>

void MatMulMat(double*, double*, double*);

int main(void)
{
	double A[2][3] = { -0.7, 1.3, 3.2, 0.2, 2.5, 0.6 };
	double B[3][2] = { 0.3, 0.7, 0.9, -0.5, -0.3, -0.6 };
	double result[3][3] = { 0, };



	printf("A x B �� ���\n");
	MatMulMat(A, B, result);
	printf("B x A �� ���\n");
	MatMulMat(B, A, result);
	for (int x = 0; x < 2; x++)
	{
		for (int y = 0; y < 2; y++)
		{
			printf("%lf\t", *(result + x + y));
		}
		printf("\n");
	}
}