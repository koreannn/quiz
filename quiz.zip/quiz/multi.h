
void MatMulMat(double* arr1, double* arr2, double* arr3)
{
	/*int a[3][2] = {1,2,3,4,5,6};
	int b[2][4] = { 1,2,3,4,5,6,7,8 };
	int result[3][4] = { 0, };

	for (int i = 0; i < 3; i++)
	{
		for (int l = 0; l < 4; l++)
		{
			for (int k = 0; k < 2; k++)
				result[i][l] += a[i][k] * b[k][l];
		}
	}
	for (int x = 0; x < 3; x++)
	{
		for (int y = 0; y < 4; y++)
		{
			printf("%d ", result[x][y]);
		}
		printf("\n");
	}*/
	for (int i = 0; i < 2; i++)
	{
		for (int l = 0; l < 2; l++)
		{
			for (int k = 0; k < 2; k++)
				*(arr3 + k) = *(arr1 + i) * *(arr2 + l);
		}
	}
}